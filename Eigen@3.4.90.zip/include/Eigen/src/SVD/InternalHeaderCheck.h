#ifndef EIGEN_SVD_MODULE_H
#error "Please include Eigen/SVD instead of including headers inside the src directory directly."
#endif
